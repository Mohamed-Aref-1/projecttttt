# Tyk Project Backend

A Node.js + Express backend with Firebase authentication and MongoDB integration.

## Features

- Firebase authentication
- Protected routes for dog and cat images
- MongoDB user storage
- Token verification middleware

## Setup

1. Install dependencies:
```bash
npm install
```

2. Create a `.env` file based on `.env.example`:
```bash
cp .env.example .env
```

3. Update the `.env` file with your Firebase credentials and MongoDB URI.

4. Start the development server:
```bash
npm run dev
```

## API Endpoints

### Authentication
- `POST /auth/login`: Verify Firebase token and create/update user

### Protected Routes
- `GET /pets/dog`: Get a random dog image
- `GET /pets/cat`: Get a random cat image

All protected routes require a valid Firebase ID token in the Authorization header:
```
Authorization: Bearer <your-firebase-token>
```

## Environment Variables

- `PORT`: Server port (default: 3000)
- `MONGODB_URI`: MongoDB connection string
- `FIREBASE_PROJECT_ID`: Your Firebase project ID
- `FIREBASE_PRIVATE_KEY`: Your Firebase private key
- `FIREBASE_CLIENT_EMAIL`: Your Firebase client email 
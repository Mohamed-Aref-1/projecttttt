const express = require('express');
const router = express.Router();
const User = require('../models/User');
const axios = require('axios');

// Function to create a Tyk API key
async function createTykApiKey(uid) {
  try {
    const response = await axios.post('http://localhost:8080/tyk/keys/create', {
      alias: uid,
      policy_id: 'limited_access'
    }, {
      headers: {
        'x-tyk-authorization': '352d20ee67be67f6340b4c0605b044b7'
      }
    });
    return response.data.key_id;
  } catch (error) {
    console.error('Error creating Tyk API key:', error);
    throw error;
  }
}

router.post('/login', async (req, res) => {
  try {
    const { uid, email } = req.user;

    let user = await User.findOne({ uid });
    if (!user) {
      user = await User.create({ uid, email });
    }

    // Check if the user already has a Tyk API key
    if (!user.tykApiKey) {
      const tykApiKey = await createTykApiKey(uid);
      user.tykApiKey = tykApiKey;
      await user.save();
    }

    res.json({ message: 'Login successful', user });
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

module.exports = router; 
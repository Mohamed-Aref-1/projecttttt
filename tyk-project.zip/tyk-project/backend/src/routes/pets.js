const express = require('express');
const router = express.Router();
const axios = require('axios');
const verifyToken = require('../middleware/auth');

router.get('/dog', verifyToken, async (req, res) => {
  try {
    const response = await axios.get('https://dog.ceo/api/breeds/image/random');
    res.json(response.data);
  } catch (error) {
    console.error('Error fetching dog image:', error);
    res.status(500).json({ error: 'Failed to fetch dog image' });
  }
});

router.get('/cat', verifyToken, async (req, res) => {
  try {
    const response = await axios.get('https://api.thecatapi.com/v1/images/search');
    res.json(response.data[0]);
  } catch (error) {
    console.error('Error fetching cat image:', error);
    res.status(500).json({ error: 'Failed to fetch cat image' });
  }
});

module.exports = router; 
// Firebase config
const firebaseConfig = {
  apiKey: "AIzaSyDen5RIs3EVotKwMN0vQIZa4-et082Ej4w",
  authDomain: "tyk-project1.firebaseapp.com",
  projectId: "tyk-project1",
  storageBucket: "tyk-project1.firebasestorage.app",
  messagingSenderId: "561600627542",
  appId: "1:561600627542:web:88a2f935f0bb033c614cf7",
  measurementId: "G-RVPV6P0JNL"
};

firebase.initializeApp(firebaseConfig);

// Function to sign up
async function signUp() {
  const email = document.getElementById('email').value;
  const password = document.getElementById('password').value;
  
  if (!email || !password) {
    showNotification('Please enter both email and password', 'error');
    return;
  }

  showLoadingState(true);
  
  try {
    const userCredential = await firebase.auth().createUserWithEmailAndPassword(email, password);
    showNotification('Successfully signed up!', 'success');
  } catch (error) {
    console.error('Error signing up:', error);
    showNotification('Error signing up: ' + error.message, 'error');
  } finally {
    showLoadingState(false);
  }
}

// Function to sign in
async function signIn() {
  const email = document.getElementById('email').value;
  const password = document.getElementById('password').value;
  
  if (!email || !password) {
    showNotification('Please enter both email and password', 'error');
    return;
  }

  showLoadingState(true);
  
  try {
    const userCredential = await firebase.auth().signInWithEmailAndPassword(email, password);
    handleUserSignIn(userCredential.user);
    showNotification('Successfully signed in!', 'success');
  } catch (error) {
    console.error('Error signing in:', error);
    showNotification('Error signing in: ' + error.message, 'error');
  } finally {
    showLoadingState(false);
  }
}

// Function to handle user sign in
async function handleUserSignIn(user) {
  const token = await user.getIdToken();
  const userInitial = user.email.charAt(0).toUpperCase();
  
  document.querySelector('.user-avatar').innerHTML = userInitial;
  document.getElementById('user-email').textContent = user.email;
  document.getElementById('user-token').textContent = token;

  document.getElementById('login-form').classList.add('hidden');
  document.getElementById('user-info').classList.remove('hidden');
  document.getElementById('pet-actions').classList.remove('hidden');
}

// Function to sign out
function signOut() {
  firebase.auth().signOut().then(() => {
    document.getElementById('login-form').classList.remove('hidden');
    document.getElementById('user-info').classList.add('hidden');
    document.getElementById('pet-actions').classList.add('hidden');
    document.getElementById('image-container').innerHTML = '';
    showNotification('Successfully signed out!', 'success');
  }).catch((error) => {
    console.error('Error signing out:', error);
    showNotification('Error signing out: ' + error.message, 'error');
  });
}

// Check if user is already logged in
firebase.auth().onAuthStateChanged(function(user) {
  if (user) {
    handleUserSignIn(user);
  }
});

// Function to fetch dog image
async function getDog() {
  document.getElementById('image-container').innerHTML = '';
  const response = await fetchWithToken('/pets/dog');
  updateRequestCounter('dog', response);
}

// Function to fetch cat image
async function getCat() {
  document.getElementById('image-container').innerHTML = '';
  const response = await fetchWithToken('/pets/cat');
  updateRequestCounter('cat', response);
}

// Function to update request counter
function updateRequestCounter(api, response) {
  const remainingRequests = response.headers.get('X-RateLimit-Remaining');
  const counterElement = document.getElementById(`${api}-counter`);
  if (counterElement) {
    counterElement.textContent = `Requests left: ${remainingRequests}`;
  }

  if (remainingRequests === '0') {
    showNotification('Quota limit exceeded for ' + api + ' API', 'error');
  }
}

// Update the fetchWithToken function to return the response
async function fetchWithToken(endpoint) {
  const token = document.getElementById('user-token').textContent;
  showLoadingState(true);0

  try {
    const response = await fetch(`http://localhost:8080${endpoint}`, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });

    if (!response.ok) {
      throw new Error('Failed to fetch image');
    }

    const data = await response.json();
    const imageUrl = data.message || data.url;

    showLoadingState(false);

    const img = document.createElement('img');
    img.src = imageUrl;
    img.alt = endpoint.includes('dog') ? 'Cute Dog' : 'Cute Cat';
    img.className = 'fade-in';
    
    document.getElementById('image-container').appendChild(img);
    return response;
  } catch (error) {
    console.error('Error fetching:', error);
    showNotification('Failed to fetch image: ' + error.message, 'error');
    showLoadingState(false);
  }
}

// Function to show/hide loading state
function showLoadingState(isLoading) {
  const loadingEl = document.getElementById('loading');
  loadingEl.style.display = isLoading ? 'flex' : 'none';
}

// Function to show notification
function showNotification(message, type) {
  let notificationContainer = document.getElementById('notification-container');
  
  if (!notificationContainer) {
    notificationContainer = document.createElement('div');
    notificationContainer.id = 'notification-container';
    notificationContainer.style.position = 'fixed';
    notificationContainer.style.top = '20px';
    notificationContainer.style.right = '20px';
    notificationContainer.style.zIndex = '1000';
    document.body.appendChild(notificationContainer);
  }
  
  const notification = document.createElement('div');
  notification.style.backgroundColor = type === 'error' ? '#ff5757' : '#36D39A';
  notification.style.color = 'white';
  notification.style.padding = '12px 20px';
  notification.style.borderRadius = '8px';
  notification.style.marginBottom = '10px';
  notification.style.boxShadow = '0 4px 12px rgba(0, 0, 0, 0.15)';
  notification.style.display = 'flex';
  notification.style.alignItems = 'center';
  notification.style.justifyContent = 'space-between';
  notification.style.animation = 'fadeIn 0.3s ease forwards';
  notification.style.maxWidth = '300px';
  
  const messageSpan = document.createElement('span');
  messageSpan.textContent = message;
  
  const closeBtn = document.createElement('button');
  closeBtn.innerHTML = '&times;';
  closeBtn.style.background = 'transparent';
  closeBtn.style.border = 'none';
  closeBtn.style.color = 'white';
  closeBtn.style.marginLeft = '10px';
  closeBtn.style.cursor = 'pointer';
  closeBtn.style.fontSize = '20px';
  closeBtn.style.padding = '0';
  closeBtn.style.lineHeight = '1';
  closeBtn.style.width = '20px';
  closeBtn.style.height = '20px';
  closeBtn.style.boxShadow = 'none';
  
  closeBtn.addEventListener('click', () => {
    notificationContainer.removeChild(notification);
  });
  
  notification.appendChild(messageSpan);
  notification.appendChild(closeBtn);
  notificationContainer.appendChild(notification);
  
  setTimeout(() => {
    if (notificationContainer.contains(notification)) {
      notificationContainer.removeChild(notification);
    }
  }, 5000);
} 